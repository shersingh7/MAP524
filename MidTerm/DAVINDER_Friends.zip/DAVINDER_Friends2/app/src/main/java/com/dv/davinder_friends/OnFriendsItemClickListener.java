package com.dv.davinder_friends;

import com.dv.davinder_friends.models.Friend;

public interface OnFriendsItemClickListener {
    void onFriendsItemClicked(Friend f);
}
