package com.jk.firedemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.jk.firedemo.databinding.ActivityMainBinding;
import com.jk.firedemo.viewmodels.FriendViewModel;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final String TAG = "MainActivity";
    ActivityMainBinding binding;
    private FriendViewModel friendViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.btnInsert.setOnClickListener(this);
        binding.btnDelete.setOnClickListener(this);
        binding.btnSearch.setOnClickListener(this);
        binding.btnUpdate.setOnClickListener(this);

        this.friendViewModel = FriendViewModel.getInstance(this.getApplication());

    }

    @Override
    public void onClick(View v) {
        if ( v!= null){
            switch (v.getId()){
                case R.id.btn_insert: {
                    Intent insertIntent = new Intent(this, InsertActivity.class);
                    startActivity(insertIntent);
                    break;
                }
                case R.id.btn_search:{
                    break;
                }
                case R.id.btn_delete:{
                    break;
                }
                case R.id.btn_update:{
                    break;
                }
            }
        }
    }

    private void toggleEditControls(Boolean state){
        binding.editUpdatePhone.setEnabled(state);
        binding.editUpdateName.setEnabled(state);
        binding.btnDelete.setEnabled(state);
        binding.btnUpdate.setEnabled(state);
    }

    private void searchFriend(){

    }
}