package com.jk.firedemo.repository;

import android.util.Log;

import com.jk.firedemo.models.Friend;

/**
 * FireDemo Created by jkp on 2021-05-28.
 */
public class FriendRepository {
    private final String TAG = this.getClass().getCanonicalName();

    public FriendRepository(){
    }

    public void addFriend(Friend friend){
        try {

        }catch (Exception ex){
            Log.e(TAG, ex.toString());
            Log.e(TAG, ex.getLocalizedMessage());
        }
    }

    public void getAllFriends(){
        try{

        }catch(Exception ex){
            Log.e(TAG, ex.getLocalizedMessage());
            Log.e(TAG, ex.toString());
        }
    }

    public void searchFriendByName(String name){
        try{

        }catch (Exception ex){
            Log.e(TAG, ex.toString());
            Log.e(TAG, ex.getLocalizedMessage());
        }
    }

    public void removeFriend(String docID){
        try{

        }catch (Exception ex){
            Log.e(TAG, ex.toString());
            Log.e(TAG, ex.getLocalizedMessage());
        }
    }

    public void updateFriend(Friend friend){
        try{

        }catch (Exception ex){
            Log.e(TAG, ex.toString());
            Log.e(TAG, ex.getLocalizedMessage());
        }
    }
}
