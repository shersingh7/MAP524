package com.jk.sharedprefdemo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

import com.jk.sharedprefdemo.databinding.ActivitySignInBinding;

public class SignInActivity extends AppCompatActivity implements View.OnClickListener{
    private ActivitySignInBinding binding;
    private final String TAG = this.getClass().getCanonicalName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySignInBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        this.binding.btnSignIn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v != null){
            switch (v.getId()){
                case R.id.btn_sign_in:{
                    Log.d(TAG, "Sign In Button Clicked");

                    if (this.verifyUser()){
                        Log.d(TAG, "Login Successful");
                        this.goToHome();
                    }else{
                        Log.e(TAG, "Incorrect email/password. Please try again!");
                    }

                    break;
                }
            }
        }
    }

    private Boolean verifyUser(){
        String email = this.binding.editEmail.getText().toString();
        String password = this.binding.editPassword.getText().toString();
        Boolean validUser = true;

        if (email.isEmpty()){
            this.binding.editEmail.setError("Email cannot be empty");
            validUser = false;
        }

        if (password.isEmpty()){
            this.binding.editPassword.setError("Password cannot be empty");
            validUser = false;
        }

        if (!email.equals("test") || !password.equals("1234")){
            return false;
        }

        return validUser;
    }

    private void goToHome(){
        Intent homeIntent = new Intent(this, MainActivity.class);
        startActivity(homeIntent);

        //remove the SignInActivity from the activity stack
        this.finishAffinity();
    }
}