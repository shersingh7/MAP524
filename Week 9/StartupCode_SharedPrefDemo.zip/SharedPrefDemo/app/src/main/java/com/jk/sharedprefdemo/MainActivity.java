package com.jk.sharedprefdemo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.jk.sharedprefdemo.databinding.ActivityMainBinding;


public class MainActivity extends AppCompatActivity {
    private final String TAG = this.getClass().getCanonicalName();
    private ActivityMainBinding binding;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_show_settings:{
                this.showSettings();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void showSettings(){
//        Intent settingsIntent = new Intent(getApplicationContext(), SettingsActivity.class);
//        startActivity(settingsIntent);
    }
}